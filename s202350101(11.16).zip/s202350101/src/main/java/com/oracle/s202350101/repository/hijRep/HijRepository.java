package com.oracle.s202350101.repository.hijRep;

public interface HijRepository {

}

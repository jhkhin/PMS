package com.oracle.s202350101.service;

import org.springframework.stereotype.Service;

@Service
public class CommonService {

}

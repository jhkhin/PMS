package com.oracle.s202350101;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S202350101ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.oracle.s202350101.model;


import java.util.List;

import lombok.Data;

@Data
public class HijRequestPrjDto {

    private int project_id;
    private int project_approve;
    private int del_status;
    private int project_order;
    private int project_step_seq;
	
}

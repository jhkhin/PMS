package com.oracle.s202350101.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

//@Date 
@Getter
@Setter
@ToString
public class AppInfo {
	private int    app_id;
	private String app_name;
	private String app_path;

}

package com.oracle.s202350101.model;

import lombok.Data;

@Data
public class HijPrjStep {

    private int project_id;
    private int project_order;
    private int project_step_seq;
	
}

package com.oracle.s202350101.repository.mkhRep;

public class MkhRepositoryImpl {

}

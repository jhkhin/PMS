package com.oracle.s202350101.dao.kjoDao;

public interface KjoDao {

}

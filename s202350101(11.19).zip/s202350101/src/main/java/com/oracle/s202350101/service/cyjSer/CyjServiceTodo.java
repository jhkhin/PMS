package com.oracle.s202350101.service.cyjSer;

import com.oracle.s202350101.model.Todo;

public interface CyjServiceTodo {

	int todoInsert(Todo todo);

}

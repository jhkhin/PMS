package com.oracle.s202350101.model;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

//@Data
@Getter
@Setter
@ToString
public class LjhResponse {
	private List<?> firList;
	private List<?> secList;
	private Object	obj;
}

package com.oracle.s202350101.dao.cyjDao;

import com.oracle.s202350101.model.Todo;

public interface CyjDaoTodo {

	int todoInsert(Todo todo);

}
